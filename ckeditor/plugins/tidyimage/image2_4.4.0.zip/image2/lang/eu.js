﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'eu', {
	alt: 'Ordezko Testua',
	btnUpload: 'Zerbitzarira bidalia',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Irudi informazioa',
	lockRatio: 'Erlazioa Blokeatu',
	menu: 'Irudi Ezaugarriak',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Tamaina Berrezarri',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Irudi Ezaugarriak',
	uploadTab: 'Gora kargatu',
	urlMissing: 'Irudiaren iturburu URL-a falta da.'
} );
